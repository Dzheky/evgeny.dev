---
id: 22202212052245
aliases: [Wednesday]
status: watching
rating: 8
---
Type: #tv
Tags: #netflix

# Wednesday Netflix Series
https://www.imdb.com/title/tt13443470/
