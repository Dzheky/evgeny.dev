
```dataview
TABLE status as "Status", rating as "Rating" FROM "Movies" SORT status ASC WHERE file.name != "Index"
```
