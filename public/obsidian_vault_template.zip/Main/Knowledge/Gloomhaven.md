---
id: 23202301221328
aliases: [Best Board Game]
---
Type: #knowledge 
Tags: [[Board Games]]

# Gloomhaven
Gloomhaven is a board game that was inspired DnD.

# References
https://gloomhaven.fandom.com/wiki/Gloomhaven_Wiki
